package com.learning;

import java.util.Arrays;

public class SortingArray 
{
	public int[] sortingArray(int[] array)
	{
		Arrays.sort(array);
		return array;
	}

}
