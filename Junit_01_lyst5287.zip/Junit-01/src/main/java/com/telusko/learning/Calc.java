package com.telusko.learning;

public class Calc 
{
   public int divide(int num1, int num2)
   {
	   return num1/num2;
   }
}
