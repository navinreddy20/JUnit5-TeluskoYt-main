package com.telusko.learning;

public class Shapes 
{
	public double computeSquareArea(double length)
	{

		return length *length;
	}
	
	public double computeCircleArea(double radius)
	{
		return 3.14*radius *radius;
	}

}
